#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd31aec96, "module_layout" },
	{ 0x82ea9962, "param_ops_uint" },
	{ 0xab9e72df, "param_ops_long" },
	{ 0xa8c93530, "ethtool_op_get_link" },
	{ 0xa089b07f, "usbnet_tx_timeout" },
	{ 0x654a41dd, "usbnet_change_mtu" },
	{ 0xe176aa35, "eth_validate_addr" },
	{ 0xc9359cc4, "usbnet_stop" },
	{ 0xbf2d5410, "usb_deregister" },
	{ 0x571fd711, "usb_register_driver" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0xa916b694, "strnlen" },
	{ 0x3c3fce39, "__local_bh_enable_ip" },
	{ 0xa4b53545, "netif_schedule_queue" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x7a2af7b4, "cpu_number" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x4b15198, "usb_autopm_put_interface" },
	{ 0xa5afb83e, "usb_autopm_get_interface" },
	{ 0x3c5d543a, "hrtimer_start_range_ns" },
	{ 0x22876d7a, "__alloc_skb" },
	{ 0x365acda7, "set_normalized_timespec64" },
	{ 0x8feae047, "softnet_data" },
	{ 0x92373373, "usbnet_start_xmit" },
	{ 0x37a0cba, "kfree" },
	{ 0x1b4931e5, "usbnet_disconnect" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x4f8a20eb, "unregister_netdev" },
	{ 0xc9ec4e21, "free_percpu" },
	{ 0x17a87585, "netdev_rx_handler_unregister" },
	{ 0xb8dce12, "kfree_skb" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x46a4b118, "hrtimer_cancel" },
	{ 0x4b0a3f52, "gic_nonsecure_priorities" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0x49f2fa43, "cpu_hwcaps" },
	{ 0xef66446f, "consume_skb" },
	{ 0x6d3fa9fb, "netif_receive_skb" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0xf424b0fe, "cpu_hwcap_keys" },
	{ 0x14b89635, "arm64_const_caps_ready" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0xc1a103c9, "usbnet_probe" },
	{ 0xd9beb5b2, "dev_queue_xmit" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xe6cc1ef1, "netif_rx_ni" },
	{ 0x349cba85, "strchr" },
	{ 0xf0099531, "arp_create" },
	{ 0xc5850110, "printk" },
	{ 0x604e7484, "usbnet_skb_return" },
	{ 0x4a5a32c1, "__netdev_alloc_skb" },
	{ 0xcc3f5490, "skb_pull" },
	{ 0x98d7354b, "skb_put" },
	{ 0x4e88c9b5, "ether_setup" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x6e720ff2, "rtnl_unlock" },
	{ 0xc6f38687, "netdev_rx_handler_register" },
	{ 0xc7a4fbed, "rtnl_lock" },
	{ 0x8ada0990, "netdev_info" },
	{ 0xdd56d605, "netdev_err" },
	{ 0xb8a5b44b, "free_netdev" },
	{ 0xe914e41e, "strcpy" },
	{ 0x5e985e72, "netif_device_attach" },
	{ 0x7606e38e, "register_netdev" },
	{ 0xaf793668, "__alloc_percpu_gfp" },
	{ 0x5e515be6, "ktime_get_ts64" },
	{ 0x2d0684a9, "hrtimer_init" },
	{ 0x91947613, "alloc_netdev_mqs" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x80ae60d6, "usbnet_resume" },
	{ 0xeef7fb86, "usbnet_suspend" },
	{ 0xdcb764ad, "memset" },
	{ 0x86332725, "__stack_chk_fail" },
	{ 0x9b94d4da, "usb_string" },
	{ 0x9ac23f86, "kmem_cache_alloc_trace" },
	{ 0x52d1fb52, "kmalloc_caches" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0x59982873, "_dev_err" },
	{ 0x4829a47e, "memcpy" },
	{ 0x986a5ca5, "usb_cdc_wdm_register" },
	{ 0x22a949fd, "usbnet_get_endpoints" },
	{ 0xb31e69d9, "usbnet_open" },
	{ 0x2ee61278, "eth_commit_mac_addr_change" },
	{ 0x54b8660f, "eth_prepare_mac_addr_change" },
	{ 0x720d8ce7, "usbnet_get_drvinfo" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xba7e6623, "netif_tx_wake_queue" },
	{ 0xd27de267, "netif_carrier_on" },
	{ 0x826e7c15, "netif_carrier_off" },
	{ 0x3feea40, "cpumask_next" },
	{ 0x3928efe9, "__per_cpu_offset" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0xa5f7cf37, "__cpu_possible_mask" },
	{ 0xad995dac, "netdev_stats_to_stats64" },
	{ 0x20000329, "simple_strtoul" },
	{ 0xec3f4348, "usb_control_msg" },
	{ 0xb2c1ec19, "usb_driver_release_interface" },
	{ 0x5f89ca6b, "__dev_kfree_skb_any" },
	{ 0x2b8ea451, "skb_push" },
	{ 0xae0dc4e9, "_dev_info" },
	{ 0x1fdc7df2, "_mcount" },
};

MODULE_INFO(depends, "cdc-wdm");

MODULE_ALIAS("usb:v05C6p9003d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v05C6p9215d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0125d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0121d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0191d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0195d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0700d*dc*dsc*dp*ic*isc*ip*in03*");
MODULE_ALIAS("usb:v2C7Cp0306d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp030Bd*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0512d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0296d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0435d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0620d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0800d*dc*dsc*dp*ic*isc*ip*in04*");
MODULE_ALIAS("usb:v2C7Cp0801d*dc*dsc*dp*ic*isc*ip*in04*");

MODULE_INFO(srcversion, "4D1B3AC521E6C0557F76B39");
