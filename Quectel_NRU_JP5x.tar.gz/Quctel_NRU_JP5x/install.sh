#!/bin/bash

if [ "$EUID" -ne 0 ]
  then echo "Please run with sudo"
  exit
fi

DRIVER_HOME=$(pwd)
cd $DRIVER_HOME/USB/v5.10.1
sudo make install

cd $DRIVER_HOME/qmi_wwan_q/
PWD=$(pwd)
KDIR=/lib/modules/$(uname -r)/build
sudo make ARCH=arm64 -C $KDIR M=$PWD modules
sudo cp qmi_wwan_q.ko /lib/modules/$(uname -r)/kernel/drivers/net/usb/
sudo depmod

cd $DRIVER_HOME/quectel-CM/
sudo make

echo "---------------------------------------------------------"
echo ">> Please reboot the system to complete the installation."
echo "---------------------------------------------------------"


