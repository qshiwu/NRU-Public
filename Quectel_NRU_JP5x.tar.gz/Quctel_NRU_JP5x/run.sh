#!/bin/bash

if [ "$EUID" -ne 0 ]
  then echo "Please run with sudo"
  exit
fi

sudo pkill quectel-CM
slepp 1
cd quectel-CM/
sudo ./quectel-CM

