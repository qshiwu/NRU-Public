#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x59253af, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x2bb8b1a9, __VMLINUX_SYMBOL_STR(register_netdevice) },
	{ 0x8487a2b6, __VMLINUX_SYMBOL_STR(flush_work) },
	{ 0xb6fcec34, __VMLINUX_SYMBOL_STR(cdev_del) },
	{ 0x2a098b39, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0xd2b09ce5, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0x9a908b80, __VMLINUX_SYMBOL_STR(test_and_clear_bit) },
	{ 0xd49c3a37, __VMLINUX_SYMBOL_STR(cdev_init) },
	{ 0xf9a482f9, __VMLINUX_SYMBOL_STR(msleep) },
	{ 0x1fdc7df2, __VMLINUX_SYMBOL_STR(_mcount) },
	{ 0xec2ac905, __VMLINUX_SYMBOL_STR(__ll_sc_atomic_sub_return) },
	{ 0x202202e3, __VMLINUX_SYMBOL_STR(up_read) },
	{ 0x13a8d2c3, __VMLINUX_SYMBOL_STR(dev_change_flags) },
	{ 0xf33847d3, __VMLINUX_SYMBOL_STR(_raw_spin_unlock) },
	{ 0x1aad7ebb, __VMLINUX_SYMBOL_STR(single_open) },
	{ 0x9b77584b, __VMLINUX_SYMBOL_STR(usbnet_resume) },
	{ 0xb7946739, __VMLINUX_SYMBOL_STR(dev_activate) },
	{ 0xbf58a035, __VMLINUX_SYMBOL_STR(param_ops_int) },
	{ 0xb8eec98b, __VMLINUX_SYMBOL_STR(del_timer) },
	{ 0x98cf60b3, __VMLINUX_SYMBOL_STR(strlen) },
	{ 0x1b17e06c, __VMLINUX_SYMBOL_STR(kstrtoll) },
	{ 0x43a53735, __VMLINUX_SYMBOL_STR(__alloc_workqueue_key) },
	{ 0x5c38bb6, __VMLINUX_SYMBOL_STR(usbnet_probe) },
	{ 0x79aa04a2, __VMLINUX_SYMBOL_STR(get_random_bytes) },
	{ 0x6b6863b6, __VMLINUX_SYMBOL_STR(single_release) },
	{ 0xd61b8b32, __VMLINUX_SYMBOL_STR(usb_reset_endpoint) },
	{ 0x85f9e742, __VMLINUX_SYMBOL_STR(is_bad_inode) },
	{ 0x6414e78, __VMLINUX_SYMBOL_STR(sock_release) },
	{ 0x83be3e36, __VMLINUX_SYMBOL_STR(usbnet_disconnect) },
	{ 0x537212b6, __VMLINUX_SYMBOL_STR(netif_carrier_on) },
	{ 0x33881055, __VMLINUX_SYMBOL_STR(dst_release) },
	{ 0x84bc974b, __VMLINUX_SYMBOL_STR(__arch_copy_from_user) },
	{ 0xde7a9c55, __VMLINUX_SYMBOL_STR(skb_copy) },
	{ 0x6b06fdce, __VMLINUX_SYMBOL_STR(delayed_work_timer_fn) },
	{ 0xfa91eb38, __VMLINUX_SYMBOL_STR(down_interruptible) },
	{ 0x784ce693, __VMLINUX_SYMBOL_STR(seq_printf) },
	{ 0x775d579a, __VMLINUX_SYMBOL_STR(netif_carrier_off) },
	{ 0xa5aad43a, __VMLINUX_SYMBOL_STR(usb_kill_urb) },
	{ 0x50173f48, __VMLINUX_SYMBOL_STR(remove_proc_entry) },
	{ 0x631e6e03, __VMLINUX_SYMBOL_STR(device_destroy) },
	{ 0xf9a3efb9, __VMLINUX_SYMBOL_STR(__ll_sc_atomic_sub) },
	{ 0x53338a71, __VMLINUX_SYMBOL_STR(__dev_kfree_skb_any) },
	{ 0xeae3dfd6, __VMLINUX_SYMBOL_STR(__const_udelay) },
	{ 0xed4a4785, __VMLINUX_SYMBOL_STR(usbnet_stop) },
	{ 0x6653c69f, __VMLINUX_SYMBOL_STR(usbnet_update_max_qlen) },
	{ 0x24130876, __VMLINUX_SYMBOL_STR(linkwatch_fire_event) },
	{ 0x8fdf772a, __VMLINUX_SYMBOL_STR(init_timer_key) },
	{ 0x1e2b50e9, __VMLINUX_SYMBOL_STR(sock_create_kern) },
	{ 0xe17e2e72, __VMLINUX_SYMBOL_STR(mutex_unlock) },
	{ 0x5f618255, __VMLINUX_SYMBOL_STR(usb_autopm_get_interface) },
	{ 0x7485e15e, __VMLINUX_SYMBOL_STR(unregister_chrdev_region) },
	{ 0xa87cf413, __VMLINUX_SYMBOL_STR(clear_bit) },
	{ 0x91715312, __VMLINUX_SYMBOL_STR(sprintf) },
	{ 0x9d13d9a9, __VMLINUX_SYMBOL_STR(seq_read) },
	{ 0xf4a597e, __VMLINUX_SYMBOL_STR(usb_unlink_urb) },
	{ 0x526c3a6c, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0xfc624a33, __VMLINUX_SYMBOL_STR(skb_trim) },
	{ 0x1472dc10, __VMLINUX_SYMBOL_STR(down_write_trylock) },
	{ 0x1f7386be, __VMLINUX_SYMBOL_STR(__ll_sc_atomic_add) },
	{ 0x2b888e76, __VMLINUX_SYMBOL_STR(__netdev_alloc_skb) },
	{ 0x22af5b79, __VMLINUX_SYMBOL_STR(netif_rx) },
	{ 0xab40cca9, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0xfa28b9ff, __VMLINUX_SYMBOL_STR(PDE_DATA) },
	{ 0xdcb764ad, __VMLINUX_SYMBOL_STR(memset) },
	{ 0x4a38b698, __VMLINUX_SYMBOL_STR(cancel_delayed_work) },
	{ 0x61744a52, __VMLINUX_SYMBOL_STR(netif_tx_stop_all_queues) },
	{ 0xa0128d73, __VMLINUX_SYMBOL_STR(usb_lock_device_for_reset) },
	{ 0x97fdbab9, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_irqrestore) },
	{ 0x8974c179, __VMLINUX_SYMBOL_STR(down_trylock) },
	{ 0xccbad838, __VMLINUX_SYMBOL_STR(usb_deregister) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x46d31ce5, __VMLINUX_SYMBOL_STR(usb_set_interface) },
	{ 0x7a20e9fe, __VMLINUX_SYMBOL_STR(fib_nl_newrule) },
	{ 0xaabef437, __VMLINUX_SYMBOL_STR(free_netdev) },
	{ 0xa8db1ead, __VMLINUX_SYMBOL_STR(usb_autopm_put_interface_async) },
	{ 0x9166fada, __VMLINUX_SYMBOL_STR(strncpy) },
	{ 0x62dbaee5, __VMLINUX_SYMBOL_STR(nla_put) },
	{ 0x8fa8f791, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_irq) },
	{ 0x70d2da1f, __VMLINUX_SYMBOL_STR(usb_control_msg) },
	{ 0x5a921311, __VMLINUX_SYMBOL_STR(strncmp) },
	{ 0x8a363b8e, __VMLINUX_SYMBOL_STR(skb_push) },
	{ 0x8c03d20c, __VMLINUX_SYMBOL_STR(destroy_workqueue) },
	{ 0xc08ad3ac, __VMLINUX_SYMBOL_STR(dev_close) },
	{ 0x1e6d26a8, __VMLINUX_SYMBOL_STR(strstr) },
	{ 0xa63eba9, __VMLINUX_SYMBOL_STR(usbnet_start_xmit) },
	{ 0xf4f14de6, __VMLINUX_SYMBOL_STR(rtnl_trylock) },
	{ 0xdfc05c53, __VMLINUX_SYMBOL_STR(device_create) },
	{ 0xfa5bcf35, __VMLINUX_SYMBOL_STR(mod_timer) },
	{ 0x2469810f, __VMLINUX_SYMBOL_STR(__rcu_read_unlock) },
	{ 0x1eb60ed2, __VMLINUX_SYMBOL_STR(usbnet_suspend) },
	{ 0x43b0c9c3, __VMLINUX_SYMBOL_STR(preempt_schedule) },
	{ 0xbe004f54, __VMLINUX_SYMBOL_STR(skb_pull) },
	{ 0xd71a6089, __VMLINUX_SYMBOL_STR(up_write) },
	{ 0x96dabfd5, __VMLINUX_SYMBOL_STR(fib_nl_delrule) },
	{ 0x52249f6f, __VMLINUX_SYMBOL_STR(fput) },
	{ 0x42160169, __VMLINUX_SYMBOL_STR(flush_workqueue) },
	{ 0x7856fdb0, __VMLINUX_SYMBOL_STR(cdev_add) },
	{ 0xb347bb2c, __VMLINUX_SYMBOL_STR(work_busy) },
	{ 0x1c1a02e1, __VMLINUX_SYMBOL_STR(usb_queue_reset_device) },
	{ 0x4253fa3f, __VMLINUX_SYMBOL_STR(init_task) },
	{ 0x7e42470a, __VMLINUX_SYMBOL_STR(__secpath_destroy) },
	{ 0x7c97c8a4, __VMLINUX_SYMBOL_STR(__ll_sc_atomic_add_return) },
	{ 0xe116877b, __VMLINUX_SYMBOL_STR(usb_submit_urb) },
	{ 0x4ee3d720, __VMLINUX_SYMBOL_STR(netif_device_detach) },
	{ 0xcd6772f2, __VMLINUX_SYMBOL_STR(__alloc_skb) },
	{ 0xd1b0a3e0, __VMLINUX_SYMBOL_STR(usb_autopm_get_interface_async) },
	{ 0xb35dea8f, __VMLINUX_SYMBOL_STR(__arch_copy_to_user) },
	{ 0x9d378f70, __VMLINUX_SYMBOL_STR(queue_delayed_work_on) },
	{ 0x1982f6ff, __VMLINUX_SYMBOL_STR(usbnet_tx_timeout) },
	{ 0xa202a8e5, __VMLINUX_SYMBOL_STR(kmalloc_order_trace) },
	{ 0xacd8f3f2, __VMLINUX_SYMBOL_STR(kfree_skb) },
	{ 0x6c7369f0, __VMLINUX_SYMBOL_STR(usbnet_pause_rx) },
	{ 0x1ad912d5, __VMLINUX_SYMBOL_STR(usb_clear_halt) },
	{ 0xd2484e0d, __VMLINUX_SYMBOL_STR(usbnet_skb_return) },
	{ 0x20ffa7f6, __VMLINUX_SYMBOL_STR(_raw_spin_lock_irq) },
	{ 0x231efe84, __VMLINUX_SYMBOL_STR(flush_delayed_work) },
	{ 0x6b2dc060, __VMLINUX_SYMBOL_STR(dump_stack) },
	{ 0xa84e4187, __VMLINUX_SYMBOL_STR(alloc_netdev_mqs) },
	{ 0x9e70ca27, __VMLINUX_SYMBOL_STR(eth_type_trans) },
	{ 0x59af4178, __VMLINUX_SYMBOL_STR(wake_up_process) },
	{ 0xd2d89eee, __VMLINUX_SYMBOL_STR(ether_setup) },
	{ 0xcc5005fe, __VMLINUX_SYMBOL_STR(msleep_interruptible) },
	{ 0x4fc2b472, __VMLINUX_SYMBOL_STR(down_read_trylock) },
	{ 0x16c22940, __VMLINUX_SYMBOL_STR(netdev_state_change) },
	{ 0x81f3f299, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0x5cd885d5, __VMLINUX_SYMBOL_STR(_raw_spin_lock) },
	{ 0x96220280, __VMLINUX_SYMBOL_STR(_raw_spin_lock_irqsave) },
	{ 0x36e353c8, __VMLINUX_SYMBOL_STR(sock_alloc_file) },
	{ 0x2a18c74, __VMLINUX_SYMBOL_STR(nf_conntrack_destroy) },
	{ 0xffbaa4ba, __VMLINUX_SYMBOL_STR(dev_deactivate) },
	{ 0x6b7ae41f, __VMLINUX_SYMBOL_STR(unregister_netdevice_queue) },
	{ 0x65345022, __VMLINUX_SYMBOL_STR(__wake_up) },
	{ 0xbff1f5ce, __VMLINUX_SYMBOL_STR(usbnet_unlink_rx_urbs) },
	{ 0x3007272, __VMLINUX_SYMBOL_STR(proc_create_data) },
	{ 0x2b289b60, __VMLINUX_SYMBOL_STR(usb_autopm_get_interface_no_resume) },
	{ 0xa4bc96d2, __VMLINUX_SYMBOL_STR(usb_autopm_put_interface_no_suspend) },
	{ 0x415d00fa, __VMLINUX_SYMBOL_STR(seq_lseek) },
	{ 0x9c55cec, __VMLINUX_SYMBOL_STR(schedule_timeout_interruptible) },
	{ 0x596ae5be, __VMLINUX_SYMBOL_STR(posix_lock_file) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x4829a47e, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0xb6e5f31c, __VMLINUX_SYMBOL_STR(usbnet_change_mtu) },
	{ 0x3f0b4a8d, __VMLINUX_SYMBOL_STR(fib_new_table) },
	{ 0xae8c4d0c, __VMLINUX_SYMBOL_STR(set_bit) },
	{ 0x324b3877, __VMLINUX_SYMBOL_STR(up) },
	{ 0x955f9999, __VMLINUX_SYMBOL_STR(usb_register_driver) },
	{ 0x5702c523, __VMLINUX_SYMBOL_STR(class_destroy) },
	{ 0xbdbc13a1, __VMLINUX_SYMBOL_STR(complete) },
	{ 0x28318305, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0x5a9f1d63, __VMLINUX_SYMBOL_STR(memmove) },
	{ 0x7f02188f, __VMLINUX_SYMBOL_STR(__msecs_to_jiffies) },
	{ 0xba44cd7e, __VMLINUX_SYMBOL_STR(dev_queue_xmit) },
	{ 0x8d522714, __VMLINUX_SYMBOL_STR(__rcu_read_lock) },
	{ 0xc0eae8b2, __VMLINUX_SYMBOL_STR(usbnet_resume_rx) },
	{ 0xb2ce072e, __VMLINUX_SYMBOL_STR(__class_create) },
	{ 0x65c4af56, __VMLINUX_SYMBOL_STR(__nlmsg_put) },
	{ 0x9ab2e264, __VMLINUX_SYMBOL_STR(usbnet_manage_power) },
	{ 0x47271692, __VMLINUX_SYMBOL_STR(usb_free_urb) },
	{ 0xb23f7032, __VMLINUX_SYMBOL_STR(__init_rwsem) },
	{ 0x6e720ff2, __VMLINUX_SYMBOL_STR(rtnl_unlock) },
	{ 0x88db9f48, __VMLINUX_SYMBOL_STR(__check_object_size) },
	{ 0x29537c9e, __VMLINUX_SYMBOL_STR(alloc_chrdev_region) },
	{ 0x11a6f63d, __VMLINUX_SYMBOL_STR(usb_autopm_put_interface) },
	{ 0x14dc0a8b, __VMLINUX_SYMBOL_STR(usb_alloc_urb) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("usb:v1199p68A2d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v05C6p920Dd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9011d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9013d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9015d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9019d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9071d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p68C0d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9041d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9051d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9053d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9054d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9055d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9056d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9061d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9070d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9091d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p90B1d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p90C1d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9100d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9102d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1199p9081d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "5ED702AD99CB9320C5015A4");
