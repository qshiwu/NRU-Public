#!/bin/bash


if [ "$EUID" -ne 0 ]
  then echo "Please run with sudo"
  exit
fi


currentPWD=$(pwd)


echo "-------------------------------"
echo "Install Sierra GobiNet Driver"
cd "${currentPWD}/GobiNet"
sudo make RAWIP=1 install -j8

echo "Install Sierra GobiSerial Driver"
cd "${currentPWD}/GobiSerial"
sudo make install -j8

echo "-------------------------------"
echo "Treat mPCI of NRU as USB Device"
sudo cp "${currentPWD}/neousys_startup_USBmPCIE.sh" /etc/init.d/neousys_startup.sh
bash /etc/init.d/neousys_startup.sh

echo "-------------------------------"
echo "Confirm USB Devices"
sleep 3
usb-devices

echo "-------------------------------"
echo "Reinstall curl"
sudo apt remove -y libcurl4
sudo apt install -y libcurl4 curl

echo "-------------------------------"
echo "Remove Old Modem Manager"
sudo apt-get remove -y modemmanager
sudo killall -9 modemmanager


echo "-------------------------------"
echo "Install the latest Modem Manager"
sudo snap install modem-manager



echo "-------------------------------"
echo "Wait 60 sec till Sierra EM7455 Ready"

sudo mmcli -S

i="0"

while [ $i -lt 100 ]
do
  printf "."
  sleep 0.6
  i=$[$i+1]
done

sudo mmcli -S
sleep 5

sudo mmcli -L

sudo mmcli -m 0


