#!/bin/bash

if [ "$EUID" -ne 0 ]
  then echo "Please run with sudo"
  exit
fi

echo "The following kernel option are expected to be y or m"

cat /proc/config.gz | zgrep CONFIG_USB_SERIAL=
cat /proc/config.gz | zgrep CONFIG_USB_SERIAL_WWAN=
cat /proc/config.gz | zgrep CONFIG_USB_SERIAL_OPTION=


### One Time Setup
# Add Blacklist to unwanted modeom driver
sudo grep -q -F 'blacklist qmi_wwan' /etc/modprobe.d/blacklist-modem.conf
sudo echo 'blacklist qmi_wwan' >>/etc/modprobe.d/blacklist-modem.conf


sudo apt update
# Install minicom
sudo apt-get install -y minicom

# Install udhcpc
sudo apt-get install -y udhcpc


# Make Simcom driver
cd sim7600_driver/
sudo make install

# Backup current NRU startup script
cd ..
# now=$(date +"%m%d%y_%H%M")
# cp /etc/init.d/neousys_startup.sh startup_script_backup/neousys_startup_$now.sh

# Copy a modified startup script for SIM7600SA
# cp neousys_start_SIM7600.sh /etc/init.d/neousys_startup.sh

# Backup current /etc/network/interfaces
now=$(date +"%Y-%m-%d_%H:%M:%S")
cp /etc/network/interfaces interfaces_backup/interfaces_$now

# Copy a modified interface for SIM7600SA
cp interfaces_sim7600 /etc/network/interfaces


echo "------------------------------------"

echo "SIMCOM 7600SA driver setup completed"
echo "Please reboot, then call 01_dialup_SIMCOM7600SA.sh to test 4G LTE"
echo "If your SIM card has password, please remember to setup your PIN code in 01_dialup_SIMCOM7600SA.sh"
