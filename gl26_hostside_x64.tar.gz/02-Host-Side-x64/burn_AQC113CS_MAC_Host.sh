#!/bin/bash

if [ "$EUID" -ne 0 ]; then
    echo "Please run with sudo"
    exit
fi

DIR="${BASH_SOURCE%/*}"
if [[ ! -d "$DIR" ]]; then DIR="$PWD"; fi
source "$DIR/../01-NX-Side/utility.sh"

echo "██████╗  ██████╗██╗███████╗     ██████╗ ██╗     ██████╗  ██████╗ "
echo "██╔══██╗██╔════╝██║██╔════╝    ██╔════╝ ██║     ╚════██╗██╔════╝ "
echo "██████╔╝██║     ██║█████╗█████╗██║  ███╗██║      █████╔╝███████╗ "
echo "██╔═══╝ ██║     ██║██╔══╝╚════╝██║   ██║██║     ██╔═══╝ ██╔═══██╗"
echo "██║     ╚██████╗██║███████╗    ╚██████╔╝███████╗███████╗╚██████╔╝"
echo "╚═╝      ╚═════╝╚═╝╚══════╝     ╚═════╝ ╚══════╝╚══════╝ ╚═════╝ "
                                                                 
readSN
readAQC113CSMACAddressStep1
readAQC113CSMACAddressStep2_Host
