#!/bin/bash

if [ "$EUID" -ne 0 ]; then
    echo "Please run with sudo"
    exit
fi


sudo apt update
sudo apt install -y build-essential
cd 01-AQC113CS/driver/Linux/
sudo make clean
sudo make
sudo make load
sudo make install


