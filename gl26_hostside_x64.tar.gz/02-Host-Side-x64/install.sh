#!/bin/bash

if [ "$EUID" -ne 0 ]
then echo "Please run with sudo"
exit
fi

shfolder=$(pwd)
echo $shfolder


echo "      :::    :::  ::::::::   :::::::: :::::::::::    "
echo "     :+:    :+: :+:    :+: :+:    :+:    :+:         "
echo "    +:+    +:+ +:+    +:+ +:+           +:+          "
echo "   +#++:++#++ +#+    +:+ +#++:++#++    +#+           "
echo "  +#+    +#+ +#+    +#+        +#+    +#+            "
echo " #+#    #+# #+#    #+# #+#    #+#    #+#             "
echo "###    ###  ########   ########     ###              "

echo "> Check Network Availability"

targetIP=www.google.com
ping -c1 -w3 $targetIP > ping_log        
pingExist=$(awk 'END{print}' ping_log)    
pingGoodPattern='^rtt' 
if [[ $pingExist =~ $pingGoodPattern ]]; then   
    echo "> Internet connected. Proceed with Package installation."
    sleep 0.5
else
    echo "!! Please connect to Internet and try again !!"
    exit
fi


#######################################
echo "> Install ifconfig"
sudo apt install -y net-tools  2>/dev/null 1>/dev/null

#######################################
echo "> Install git"
sudo apt-get install git  2>/dev/null 1>/dev/null

#######################################
echo "> Install ssh"

# Install SSH 
sudo apt-get install openssh-server 1>/dev/null
sudo service ssh start 1>/dev/null

# Make SSH start after booting
sudo systemctl enable ssh 1>/dev/null

# Check SSH Status
sudo systemctl status ssh.service

# Allow SSH on Firewall
sudo ufw allow ssh 1>/dev/null



#######################################
echo "> Install GStreamer Plugin"
# Ref https://gstreamer.freedesktop.org/documentation/installing/on-linux.html?gi-language=c
sudo apt-get install -y libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev libgstreamer-plugins-bad1.0-dev gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav gstreamer1.0-doc gstreamer1.0-tools gstreamer1.0-x gstreamer1.0-alsa gstreamer1.0-gl gstreamer1.0-gtk3 gstreamer1.0-qt5 gstreamer1.0-pulseaudio 2>/dev/null 1>/dev/null


#######################################
echo "> install PCIe-GL26 shutdown helper"
cd 02-gentle-shutdown-gl26
sudo ./install_stop_script.sh
cd $shfolder

#######################################
echo "> Install AQC113CS Driver"
# Install AQC113CS Driver
sudo ./install_AQC113CS_drive_Host.sh 
cd $shfolder

#######################################
echo "> ****************************************"
echo "> Remember to Set IP for AQC113CS Manually"
echo "> Board ID#0 _ Host Side _ 26.26.50.51"
echo "> Board ID#1 _ Host Side _ 26.26.51.51"
echo "> Board ID#2 _ Host Side _ 26.26.52.51"
echo "> Board ID#3 _ Host Side _ 26.26.53.51"
echo "> ****************************************"
