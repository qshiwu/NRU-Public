#!/bin/bash

### Check root permission
if [ "$EUID" -ne 0 ]; then
    echo "Please run with sudo"
    exit
fi


echo "      :::    :::  ::::::::   :::::::: :::::::::::    "
echo "     :+:    :+: :+:    :+: :+:    :+:    :+:         "
echo "    +:+    +:+ +:+    +:+ +:+           +:+          "
echo "   +#++:++#++ +#+    +:+ +#++:++#++    +#+           "
echo "  +#+    +#+ +#+    +#+        +#+    +#+            "
echo " #+#    #+# #+#    #+# #+#    #+#    #+#             "
echo "###    ###  ########   ########     ###              "

echo "> Check Network Availability"

targetIP=www.google.com
ping -c1 -w3 $targetIP > ping_log        
pingExist=$(awk 'END{print}' ping_log)    
pingGoodPattern='^rtt' 
if [[ $pingExist =~ $pingGoodPattern ]]; then   
    echo "> Internet connected. Proceed with Package installation."
    sleep 0.5
else
    echo "!! Please connect to Internet and try again !!"
    exit
fi


sleep 0.5

#######################################
echo "> Install SSH"

# Install SSH
sudo apt-get install openssh-server 1>/dev/null
sudo service ssh start 1>/dev/null

# Make SSH start after booting
sudo systemctl enable ssh 1>/dev/null

# Check SSH Status
sudo systemctl status ssh.service

# Allow SSH on Firewall
sudo ufw allow ssh 1>/dev/null


sleep 0.5


#######################################
echo "> Install sshpass"

# Install sshpass
sudo apt-get install sshpass

sleep 0.5

#######################################

echo "Expected: "
echo "> GL26 username: nvidia"
echo "> GL26 password: nvidia"
echo "> GL26 IPs: 26.26.50.50, 26.26.51.50, 26.26.52.50, 26.26.53.50"
echo "> script name: gl26stop"
echo "> will send 'ssh shutdown now' to GL26 during host shutdown process"

sleep 0.5

ts=$(date +"%Y-%m-%d_%T")

sudo cp gl26stop /etc/init.d/
sudo chown root:root /etc/init.d/gl26stop
sudo chmod +x /etc/init.d/gl26stop
sudo update-rc.d gl26stop remove
sudo update-rc.d gl26stop defaults
sudo update-rc.d gl26stop enable 5

