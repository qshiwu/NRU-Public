#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0xb3753869, "module_layout" },
	{ 0xedf41f4c, "kobject_put" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x7ec5ff3f, "netdev_info" },
	{ 0x35216b26, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x17e87c4f, "ethtool_op_get_ts_info" },
	{ 0x212342d0, "__pm_runtime_idle" },
	{ 0x4204fe01, "skb_clone_tx_timestamp" },
	{ 0x7381287f, "trace_handle_return" },
	{ 0x5d863697, "pci_free_irq_vectors" },
	{ 0x979bdcd9, "sysfs_remove_bin_file" },
	{ 0x5ab5b891, "param_ops_int" },
	{ 0x9a34a2b, "crc_itu_t" },
	{ 0xce31b2fe, "napi_disable" },
	{ 0x71afadc1, "napi_schedule_prep" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0xd8fd6a9a, "dma_set_mask" },
	{ 0x8fae8099, "pci_disable_device" },
	{ 0xc7a4fbed, "rtnl_lock" },
	{ 0x2a40c3fa, "netdev_set_num_tc" },
	{ 0xae774fa9, "netif_carrier_on" },
	{ 0xc0a3d105, "find_next_bit" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0xdf566a59, "__x86_indirect_thunk_r9" },
	{ 0x93001175, "netif_carrier_off" },
	{ 0x56470118, "__warn_printk" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0xb43f9365, "ktime_get" },
	{ 0xbddf62d2, "dma_direct_sync_single_for_cpu" },
	{ 0xc29957c3, "__x86_indirect_thunk_rcx" },
	{ 0x823782d3, "__dev_kfree_skb_any" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x23de47c2, "pci_release_regions" },
	{ 0xededc3c3, "param_ops_bool" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0x9fa7184a, "cancel_delayed_work_sync" },
	{ 0x409bcb62, "mutex_unlock" },
	{ 0xd539f1b5, "__pm_runtime_resume" },
	{ 0xf49df4cc, "trace_event_buffer_reserve" },
	{ 0x62fd0331, "kobject_del" },
	{ 0x2b54d1d5, "dma_free_attrs" },
	{ 0x49bc742c, "pm_runtime_forbid" },
	{ 0x4629334c, "__preempt_count" },
	{ 0x165b145c, "ex_handler_refcount" },
	{ 0x7a2af7b4, "cpu_number" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x287e6611, "bpf_trace_run3" },
	{ 0x11e66d2, "__alloc_pages_nodemask" },
	{ 0x36e58bcd, "pv_ops" },
	{ 0x32ffdcca, "dma_set_coherent_mask" },
	{ 0xb731232f, "netif_napi_del" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3095109f, "__dynamic_netdev_dbg" },
	{ 0x26d6900d, "kobject_create_and_add" },
	{ 0xae2b022a, "devm_hwmon_device_register_with_info" },
	{ 0x157c56dc, "ptp_clock_unregister" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0xcf74b521, "netdev_set_tc_queue" },
	{ 0x5ab71bb8, "pci_set_master" },
	{ 0x8b2f6aa2, "ptp_clock_event" },
	{ 0x97934ecf, "del_timer_sync" },
	{ 0x64cd8a25, "pci_alloc_irq_vectors_affinity" },
	{ 0x834df655, "trace_define_field" },
	{ 0xfb578fc5, "memset" },
	{ 0x1e1e140e, "ns_to_timespec64" },
	{ 0x361dee29, "netif_tx_wake_queue" },
	{ 0xdd8e5edc, "bpf_trace_run1" },
	{ 0x67ec8351, "pci_restore_state" },
	{ 0x5ab4b5b4, "netif_tx_stop_all_queues" },
	{ 0x3812050a, "_raw_spin_unlock_irqrestore" },
	{ 0x977f511b, "__mutex_init" },
	{ 0xc5850110, "printk" },
	{ 0x6ef7ab52, "ethtool_op_get_link" },
	{ 0x3c3fce39, "__local_bh_enable_ip" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x5a5a2271, "__cpu_online_mask" },
	{ 0x9ec6ca96, "ktime_get_real_ts64" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xf26c4412, "free_netdev" },
	{ 0xe7b00dfb, "__x86_indirect_thunk_r13" },
	{ 0x9db7a1d6, "trace_event_reg" },
	{ 0x706b0597, "register_netdev" },
	{ 0x37805d7b, "dma_direct_map_page" },
	{ 0x5792f848, "strlcpy" },
	{ 0xfda0bdf3, "dma_alloc_attrs" },
	{ 0x2ab7989d, "mutex_lock" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x4c3ddda0, "dev_close" },
	{ 0xd241452, "netif_set_real_num_rx_queues" },
	{ 0xf4f14de6, "rtnl_trylock" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0xdba96718, "netif_set_real_num_tx_queues" },
	{ 0xff6c36ee, "netif_napi_add" },
	{ 0xd635ff26, "ptp_clock_register" },
	{ 0x2072ee9b, "request_threaded_irq" },
	{ 0xfb251b8d, "kobject_add" },
	{ 0xe6257e29, "_dev_err" },
	{ 0xd204d5bc, "perf_trace_run_bpf_submit" },
	{ 0xad5f0017, "perf_trace_buf_alloc" },
	{ 0x9f46ced8, "__sw_hweight64" },
	{ 0x9d5f0aa0, "dev_open" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0x22f50319, "eth_get_headlen" },
	{ 0x9aec514a, "pci_select_bars" },
	{ 0x9e163a88, "dma_direct_unmap_page" },
	{ 0x3df60159, "netif_device_attach" },
	{ 0xe29d50fb, "napi_gro_receive" },
	{ 0xceeb51d6, "__free_pages" },
	{ 0xb601be4c, "__x86_indirect_thunk_rdx" },
	{ 0x618911fc, "numa_node" },
	{ 0x24984367, "netif_device_detach" },
	{ 0x93a219c, "ioremap_nocache" },
	{ 0xf5bad929, "__napi_schedule" },
	{ 0x8e087c70, "trace_event_ignore_this_pid" },
	{ 0xb2fcb56d, "queue_delayed_work_on" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0x9cb986f2, "vmalloc_base" },
	{ 0x9922d81, "pm_schedule_suspend" },
	{ 0xc4f5eebc, "napi_complete_done" },
	{ 0x2b215a8c, "__pm_runtime_set_status" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0x5583725, "eth_type_trans" },
	{ 0x9ae5c578, "ptp_find_pin" },
	{ 0xa0af56b7, "trace_event_buffer_commit" },
	{ 0x38c0115f, "dev_driver_string" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x19a9fc08, "netdev_err" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xf7744a0f, "pci_unregister_driver" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0xf5cb25c8, "kmem_cache_alloc_trace" },
	{ 0xdbf17652, "_raw_spin_lock" },
	{ 0x51760917, "_raw_spin_lock_irqsave" },
	{ 0x3f2627a9, "pci_irq_vector" },
	{ 0x34e70c1, "event_triggers_call" },
	{ 0x61407a47, "scaled_ppm_to_ppb" },
	{ 0x1c717f6b, "pci_set_power_state" },
	{ 0x69cb3075, "netdev_warn" },
	{ 0xd8754ee, "bpf_trace_run2" },
	{ 0x37a0cba, "kfree" },
	{ 0x3673a548, "remap_pfn_range" },
	{ 0x69acdf38, "memcpy" },
	{ 0x933c92c6, "trace_event_raw_init" },
	{ 0x3bb68935, "pci_request_regions" },
	{ 0xa3bf6975, "param_array_ops" },
	{ 0x27c3c7a0, "ptp_clock_index" },
	{ 0x88b59648, "skb_add_rx_frag" },
	{ 0xedc03953, "iounmap" },
	{ 0x7d82ab27, "sysfs_create_bin_file" },
	{ 0x9b30e22e, "kobject_init" },
	{ 0x2b9ca1ff, "__pci_register_driver" },
	{ 0x15af7f4, "system_state" },
	{ 0x53569707, "this_cpu_off" },
	{ 0xae384beb, "request_firmware" },
	{ 0x74c134b9, "__sw_hweight32" },
	{ 0xde0eeba1, "unregister_netdev" },
	{ 0xfca6d694, "trace_raw_output_prep" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x525d0aa3, "trace_seq_printf" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0x50d5d4b7, "__napi_alloc_skb" },
	{ 0xc60d0620, "__num_online_cpus" },
	{ 0x41ac2f7a, "skb_tstamp_tx" },
	{ 0xc089e356, "pci_enable_device" },
	{ 0x9dc82e45, "pci_wake_from_d3" },
	{ 0xf705441e, "eth_mac_addr" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0x59c6aff4, "irq_set_affinity_hint" },
	{ 0x999f25e3, "param_ops_uint" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0x77106d4c, "release_firmware" },
	{ 0x6e720ff2, "rtnl_unlock" },
	{ 0xdd7bab0c, "dma_ops" },
	{ 0xec0542d, "device_set_wakeup_enable" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x1126cb2d, "alloc_etherdev_mqs" },
};

MODULE_INFO(depends, "crc-itu-t");

MODULE_ALIAS("pci:v00001D6Ad00000001sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad0000D100sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad0000D107sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad0000D108sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad0000D109sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000000B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000007B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000008B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000009B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000011B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000012B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000080B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000087B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000088B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000089B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000091B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000092B1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000004C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000000C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000014C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000034C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000012C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000011C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000094C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001D6Ad000093C0sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "852CC21BDA9F864AC936D4B");
