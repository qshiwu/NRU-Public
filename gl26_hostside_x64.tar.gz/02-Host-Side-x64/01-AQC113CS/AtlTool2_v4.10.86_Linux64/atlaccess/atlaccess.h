/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note
 *
 * atlaccess memory access driver.
 *
 * Copyright (C) 2020 Marvell Technology Group Ltd.
 */

#ifndef ATLACCESS_DRIVER_H
#define ATLACCESS_DRIVER_H

#define ATLACCESS_DRVNAME "atlaccess"
#define ATLACCESS_DRVFILE "/dev/atlaccess"

typedef struct
{
    unsigned long addr;
    unsigned long size;
    void *buff;
} access_mem_t;

#define ATLACCESS_IOCTL_MAGIC 'a'
#define ATLACCESS_IOCTL_MMAP   _IOWR(ATLACCESS_IOCTL_MAGIC, 1, access_mem_t)
#define ATLACCESS_IOCTL_MUNMAP _IOWR(ATLACCESS_IOCTL_MAGIC, 2, access_mem_t)
#define ATLACCESS_IOCTL_READ   _IOWR(ATLACCESS_IOCTL_MAGIC, 3, access_mem_t)
#define ATLACCESS_IOCTL_WRITE  _IOWR(ATLACCESS_IOCTL_MAGIC, 4, access_mem_t)
#define ATLACCESS_IOCTL_MAX    4

#endif // ATLACCESS_DRIVER_H
