/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note
 *
 * atlaccess memory access driver.
 *
 * Copyright (C) 2020 Marvell Technology Group Ltd.
 */

#include <asm/io.h>
#include <linux/cdev.h>
#include <linux/debugfs.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/ioctl.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/version.h>
#include <linux/vmalloc.h>

// #define DEBUG

#if LINUX_VERSION_CODE > KERNEL_VERSION(4, 11, 0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#endif

#include "atlaccess.h"

#define atlaccess_printf(...) printk(KERN_INFO ATLACCESS_DRVNAME ": " __VA_ARGS__)

static dev_t atlaccess_dev;
static struct class *atlaccess_class;
static struct cdev atlaccess_cdev;

static LIST_HEAD(mem_regions);
static DEFINE_SPINLOCK(lock);

typedef struct
{
    struct list_head link;
    unsigned long addr;
    unsigned long size;
    void __iomem *iobase;
    int usage;
} mem_region_t;

static long atlaccess_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

static struct file_operations atlaccess_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = atlaccess_ioctl,
};

#define mem_region_overlap(reg1, reg2) \
    (((reg1)->addr <= ((reg2)->addr + (reg2)->size)) && ((reg2)->addr <= ((reg1)->addr + (reg1)->size)))

static inline void mem_region_union(mem_region_t *reg1, mem_region_t *reg2)
{
    unsigned long addr;

    addr = min(reg1->addr, reg2->addr);
    reg1->size = max(reg1->addr + reg1->size, reg2->addr + reg2->size) - addr;
    reg1->addr = addr;
    reg1->usage += reg2->usage;
}

static int atlaccess_mmap(access_mem_t __user *arg)
{
    access_mem_t access_mem;
    mem_region_t *iter, *safe;
    mem_region_t *new_reg;

    if (copy_from_user(&access_mem, arg, sizeof(access_mem_t)))
        return -EFAULT;

    if ((new_reg = kzalloc(sizeof(sizeof(mem_region_t)), GFP_KERNEL)) == NULL)
        return -ENOMEM;

    new_reg->addr = access_mem.addr;
    new_reg->size = access_mem.size;
    new_reg->usage = 1;

    list_for_each_entry_safe(iter, safe, &mem_regions, link)
    {
        if (mem_region_overlap(new_reg, iter))
        {
#ifdef DEBUG
            atlaccess_printf("removing overlapping region: 0x%08lX-0x%08lX (%d)\n", iter->addr, iter->addr + iter->size, iter->usage);
#endif
            mem_region_union(new_reg, iter);
            iounmap(iter->iobase);
            list_del(&iter->link);
            kfree(iter);
        }
    }

    if ((new_reg->iobase = ioremap_nocache(access_mem.addr, access_mem.size)) == NULL)
    {
        kfree(new_reg);
        return -EINVAL;
    }
    list_add_tail(&new_reg->link, &mem_regions);
#ifdef DEBUG
    atlaccess_printf("adding region: 0x%08lX-0x%08lX (%d)\n", new_reg->addr, new_reg->addr + new_reg->size, new_reg->usage);
#endif

    return 0;
}

static int atlaccess_munmap(access_mem_t __user *arg)
{
    access_mem_t access_mem;
    mem_region_t *iter, *safe;

    if (copy_from_user(&access_mem, arg, sizeof(access_mem_t)))
        return -EFAULT;

    list_for_each_entry_safe(iter, safe, &mem_regions, link)
    {
        if (mem_region_overlap(&access_mem, iter))
        {
            iter->usage--;

            if (iter->usage <= 0)
            {
#ifdef DEBUG
                atlaccess_printf("removing region: 0x%08lX-0x%08lX\n", iter->addr, iter->addr + iter->size);
#endif
                iounmap(iter->iobase);
                list_del(&iter->link);
                kfree(iter);
            }
            else
            {
#ifdef DEBUG
                atlaccess_printf("decreasing usage of region: 0x%08lX-0x%08lX (%d)\n", iter->addr, iter->addr + iter->size, iter->usage);
#endif
            }

            break;
        }
    }

    return 0;
}

static int atlaccess_read(access_mem_t __user *arg)
{
    access_mem_t access_mem;
    mem_region_t *iter;
    void __iomem *addr;

    if (copy_from_user(&access_mem, arg, sizeof(access_mem_t)))
        return -EFAULT;

    list_for_each_entry(iter, &mem_regions, link)
    {
        if (mem_region_overlap(&access_mem, iter))
        {
            addr = (char *)iter->iobase + (access_mem.addr - iter->addr);

            if (access_mem.size == 4)
            {
                u32 val32 = ioread32(addr);

                if (copy_to_user(access_mem.buff, &val32, 4))
                    return -EFAULT;
            }
#ifdef ioread64
            else if (access_mem.size == 8)
            {
                u64 val64 = ioread64(addr);

                if (copy_to_user(access_mem.buff, &val64, 8))
                    return -EFAULT;
            }
#endif
            else
            {
                return -EINVAL;
            }

            return 0;
        }
    }

    return -ENODEV;
}

static int atlaccess_write(access_mem_t __user *arg)
{
    access_mem_t access_mem;
    mem_region_t *iter;
    void __iomem *addr;

    if (copy_from_user(&access_mem, arg, sizeof(access_mem_t)))
        return -EFAULT;

    list_for_each_entry(iter, &mem_regions, link)
    {
        if (mem_region_overlap(&access_mem, iter))
        {
            addr = (char *)iter->iobase + (access_mem.addr - iter->addr);

            if (access_mem.size == 4)
            {
                u32 val32 = 0;

                if (copy_from_user(&val32, access_mem.buff, 4))
                    return -EFAULT;

                iowrite32(val32, addr);
            }
#ifdef iowrite64
            else if (access_mem.size == 8)
            {
                u64 val64 = 0;

                if (copy_from_user(&val64, access_mem.buff, 8))
                    return -EFAULT;

                iowrite32(val64, addr);
            }
#endif
            else
            {
                return -EINVAL;
            }

            return 0;
        }
    }

    return -ENODEV;
}

static long atlaccess_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    int ret = 0;
    unsigned long flags;

    if ((_IOC_TYPE(cmd) != ATLACCESS_IOCTL_MAGIC) || (_IOC_NR(cmd) > ATLACCESS_IOCTL_MAX))
        return -ENOTTY;

    spin_lock_irqsave(&lock, flags);

    switch (cmd)
    {
    case ATLACCESS_IOCTL_MMAP:
        ret = atlaccess_mmap((access_mem_t __user *)arg);
        break;
    case ATLACCESS_IOCTL_MUNMAP:
        ret = atlaccess_munmap((access_mem_t __user *)arg);
        break;
    case ATLACCESS_IOCTL_READ:
        ret = atlaccess_read((access_mem_t __user *)arg);
        break;
    case ATLACCESS_IOCTL_WRITE:
        ret = atlaccess_write((access_mem_t __user *)arg);
        break;
    default:
        ret = -ENOTTY;
        break;
    }

    spin_unlock_irqrestore(&lock, flags);

    return ret;
}

static int __init atlaccess_init(void)
{
    if (alloc_chrdev_region(&atlaccess_dev, 0, 1, ATLACCESS_DRVFILE) < 0)
    {
        atlaccess_printf("cannot allocate major number for device\n");
        return -1;
    }

    cdev_init(&atlaccess_cdev, &atlaccess_fops);

    if (cdev_add(&atlaccess_cdev, atlaccess_dev, 1) < 0)
    {
        atlaccess_printf("cannot add device to the system\n");
        goto err_reg;
    }

    if ((atlaccess_class = class_create(THIS_MODULE, ATLACCESS_DRVNAME)) == NULL)
    {
        atlaccess_printf("cannot create device class\n");
        goto err_cdev;
    }

    if (device_create(atlaccess_class, NULL, atlaccess_dev, NULL, ATLACCESS_DRVNAME) == NULL)
    {
        atlaccess_printf("cannot create device\n");
        goto err_class;
    }
    atlaccess_printf("device created\n");

    return 0;

err_class:
    class_destroy(atlaccess_class);

err_cdev:
    cdev_del(&atlaccess_cdev);

err_reg:
    unregister_chrdev_region(atlaccess_dev, 1);

    return -1;
}

static void clear_mem_regions(void)
{
    mem_region_t *iter, *safe;

    list_for_each_entry_safe(iter, safe, &mem_regions, link)
    {
#ifdef DEBUG
        atlaccess_printf("freeing region 0x%08lX-0x%08lX\n", iter->addr, iter->addr + iter->size);
#endif
        iounmap(iter->iobase);
        list_del(&iter->link);
        kfree(iter);
    }
}

static void __exit atlaccess_exit(void)
{
    clear_mem_regions();

    device_destroy(atlaccess_class, atlaccess_dev);
    class_destroy(atlaccess_class);
    cdev_del(&atlaccess_cdev);
    unregister_chrdev_region(atlaccess_dev, 1);
    atlaccess_printf("device removed\n");
}

module_init(atlaccess_init);
module_exit(atlaccess_exit);

MODULE_LICENSE("GPL v2");
MODULE_AUTHOR("Marvell Technology Group Ltd");
MODULE_DESCRIPTION("A simple driver to access PC RAM (device IO)");
MODULE_VERSION("1.0");
