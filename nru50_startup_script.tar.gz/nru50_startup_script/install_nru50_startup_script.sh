#!/bin/bash

if [ "$EUID" -ne 0 ]
  then echo "Please run with sudo"
  exit
fi


export STARTUP_SCRIPT=nru50_startup_script.sh
sudo chmod +x $STARTUP_SCRIPT
bash $STARTUP_SCRIPT

sudo chown root:root $STARTUP_SCRIPT
sudo cp $STARTUP_SCRIPT /etc/init.d/
sudo update-rc.d $STARTUP_SCRIPT remove
sudo update-rc.d  $STARTUP_SCRIPT defaults
sudo update-rc.d  $STARTUP_SCRIPT enable 5 


### COM / Disable Debug UART
###############################################
sudo systemctl stop nvgetty
sudo systemctl disable nvgetty
###############################################

### Change Power Button behavior to shutdown for IGN
gsettings set org.gnome.settings-daemon.plugins.power button-power 'shutdown'



echo ""
echo "NRU-50 Startup Script Installed!"
echo ""
