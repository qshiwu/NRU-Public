#!/bin/sh
### BEGIN INIT INFO
# Provides:          Neousys
# Required-Start:    $local_fs $remote_fs $syslog $time
# Required-Stop:     $local_fs $remote_fs $syslog $time
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Run NRU-50 startup jobs
# Description: Init ignition power feature, CAN Bus, and disable debug UART
### END INIT INFO

# ref: https://wiki.debian.org/LSBInitScripts

### CAN Bus Configure
modprobe can
modprobe can-raw
modprobe mttcan
# Change CAN Bus depnding on your application
sudo ip link set can0 up type can bitrate 500000



### To Make Ignition Power Control Possible on Ubuntu
# When boot into OS successfully, issue "IGN_OKAY" to the onboard MCU
sudo echo 408 >/sys/class/gpio/export
sudo echo out >/sys/class/gpio/gpio408/direction
sudo echo 0 >/sys/class/gpio/gpio408/value


### Change Power Button behaviour -> Moved to installation
# Setup in install script
# Ref: https://askubuntu.com/questions/66723/how-do-i-modify-the-options-for-the-power-button
# gsettings set org.gnome.settings-daemon.plugins.power button-power 'shutdown'
# gsettings get org.gnome.settings-daemon.plugins.power button-power
# gsettings set org.gnome.settings-daemon.plugins.power button-power 'interactive'
