#!/bin/bash


if [ "$EUID" -ne 0 ]
  then echo "Please run with sudo"
  exit
fi


currentPWD=$(pwd)
# For JetPack 5.x
sudo apt install selinux-utils
sudo touch /etc/selinux/config
sudo chown $USER /etc/selinux/config
sudo echo 'SELINUX=disabled' >> /etc/selinux/config

sudo chown $USER /etc/modprobe.d/blacklist-modem.conf
sudo echo 'blacklist cdc_mbim' >>/etc/modprobe.d/blacklist-modem.conf

# sudo cat /var/lib/NetworkManager/NetworkManager.state
# [main]
# NetworkingEnabled=true
# WirelessEnabled=true
# WWANEnabled=false

# Don't know if must
sudo apt-get remove usb-modeswitch

echo "-------------------------------"
echo "Install Sierra GobiNet Driver"
cd "${currentPWD}/GobiNet"
sudo make RAWIP=1 install -j6

echo "Install Sierra GobiSerial Driver"
cd "${currentPWD}/GobiSerial"
sudo make install -j6

echo "-------------------------------"
echo "Confirm USB Devices"
sleep 3
usb-devices

echo "-------------------------------"
echo "Reinstall curl"
sudo apt remove -y libcurl4
sudo apt install -y libcurl4 curl


# Removing modemmanager (1.10.0-1~ubuntu18.04.2) .
echo "-------------------------------"
echo "Remove Old Modem Manager"
sudo apt-get remove -y modemmanager
sudo killall -9 modemmanager


# modem-manager 1.8.0-12 from Canonical✓ installed
echo "-------------------------------"
echo "Install the latest Modem Manager"
sudo snap install modem-manager

echo "-------------------------------"
echo "Wait 60 sec till Sierra EM7455 Ready"

sudo mmcli -S

i="0"

while [ $i -lt 100 ]
do
  printf "."
  sleep 0.6
  i=$[$i+1]
done

sudo mmcli -S
sleep 5

sudo mmcli -L

sudo mmcli -m 0


